<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ProductAccessMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next, string $productCode): Response
    {
        $user = auth()->user();

        // Super Admin Bypass
        if ($user->role === 'super_admin') {
            return $next($request);
        }

        $hasAccess = $user->products()
            ->where('code', $productCode)
            ->where('status', true) // Product active hona chahiye
            ->exists();

        if (!$hasAccess) {
            abort(403, 'Product inactive or access denied.');
        }

        return $next($request);
    }
}